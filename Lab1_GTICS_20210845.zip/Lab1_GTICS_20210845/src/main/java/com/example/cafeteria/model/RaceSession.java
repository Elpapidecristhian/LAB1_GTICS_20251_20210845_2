package com.example.cafeteria.model;

public class RaceSession {
}
